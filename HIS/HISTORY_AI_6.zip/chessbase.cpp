//
//  chessbase.cpp
//  Beast Chess for Test
//
//  Created by Runzhe Yang on 12/4/14.
//  Copyright (c) 2014 Runzhe Yang. All rights reserved.
//

#include "chessbase.h"
#include <iostream>
#include <tuple>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <cmath>

namespace CHESSBASE
{
    void Initialize(MAP (*map)[7], MY_ANIMAL cc[], ENEMY dd[])
    {
        for (int i = 0; i < 8; ++i){
            for (int j = 0; j < 4; ++j){
                cc[i].value_of_step[j] = 0;}
            cc[i].isAlive = true;}
        
        for (int i= 0; i < 8; ++i)
            dd[i].isAlive = true;
        
        for (int i = 0; i < 3; ++i)
            for (int j = 0; j < 7; ++j)
                if (map[i][j].atype > 0){
                    cc[map[i][j].atype - 1].x = i;
                    cc[map[i][j].atype - 1].y = j;}
        
        for (int i = 6; i < 9; ++i)
            for (int j = 0; j < 7; ++j)
                if (map[i][j].atype > 0){
                    dd[map[i][j].atype - 1].x = i;
                    dd[map[i][j].atype - 1].y = j;}
    }
    
    void Refresh(MAP (*map)[7], MY_ANIMAL cc[], ENEMY dd[], const animal_type chesscode, const int to_x, const int to_y, const int who, const int my_idd)
    {
        if (who == my_idd)
        {
            map[cc[chesscode - 1].x][cc[chesscode - 1].y].atype = nanan;
            
            if (map[to_x][to_y].atype != nanan){
                if (dd[map[to_x][to_y].atype - 1].x == to_x && dd[map[to_x][to_y].atype - 1].y == to_y)
                        dd[map[to_x][to_y].atype - 1].isAlive = false;}
            map[to_x][to_y].atype = chesscode;
            
            cc[chesscode - 1].x = to_x;
            cc[chesscode - 1].y = to_y;
        }
        else
        {
            map[dd[chesscode - 1].x][dd[chesscode - 1].y].atype = nanan;
            
            if (map[to_x][to_y].atype != nanan)
            {   if (cc[map[to_x][to_y].atype - 1].x == to_x && cc[map[to_x][to_y].atype - 1].y == to_y)
                    cc[map[to_x][to_y].atype - 1].isAlive = false;
                    std::cout<<"!^@#%$&"<<std::endl;}
            
            map[to_x][to_y].atype = chesscode;
            
            dd[chesscode - 1].x = to_x;
            dd[chesscode - 1].y = to_y;
        }
        
        for (int i = 0; i < 8; ++i){
            std::cout << i << " on " << "(" << cc[i].x << ", " << cc[i].y << ") " << cc[i].isAlive << std::endl;}
        std::cout << std::endl;
        for (int i = 0; i < 8; ++i){
            std::cout << "e " << i << " on " << "(" << dd[i].x << ", " << dd[i].y << ") " << dd[i].isAlive << std::endl;}
    }
    
    
    //To give the move a value..........
    
    int Try_Move(const animal_type & chesscode, const step_type & direction, const MAP (*map)[7], const MY_ANIMAL cc[], const ENEMY dd[])
    {
        LOCATION to;
        to = What_Is_Next(chesscode, cc[chesscode - 1].x, cc[chesscode - 1].y, direction, map);
        
        if (!Is_Step_Valid(chesscode, map, to, direction, cc))
            return 0;
        else
        {
            int big = 0;
            
            if (chesscode >= tiger && chesscode <= lion) big = 7;
            // original chesscode - 1
            else if (chesscode == elephant) big = 1;
            
            if (cc[chesscode - 1].x > 2 && big != 0) big = 1; // adjust for defence
            
            if (To_Danger(to, chesscode, map, cc, dd) && Vdis(to) < 90) return 1;
            
            if (To_Danger_Specail(to, chesscode, map, cc, dd) && Vdis(to) < 90)
                return 1;
            
            if (Stop_For_Defense(chesscode, map, cc, dd)) return 1;
            
            if (In_Assistant(chesscode, map, cc, dd)) return 1;
            
            if (In_Gentle_Help(chesscode, map, cc, dd)) return 2;
            
            int jumpbonus = 0;
            if ((chesscode == tiger || chesscode == lion) && (direction == left || direction == right))
                if (abs(to.y - cc[chesscode - 1].y) > 1 && to.y != 3) {
                    jumpbonus = 2;
                    animal_type tea = map[cc[chesscode - 1].x - 1][cc[chesscode - 1].y].atype;
                    if (tea == lion) {
                        if (cc[tea - 1].isAlive == true && cc[tea - 1].x == 2 && cc[tea - 1].y == 3) jumpbonus += 10;}}
            
            return Vdis(to) - In_Danger_Simple(chesscode, map, cc, dd) - In_Danger_Special(chesscode, map, cc, dd) + Yammy(to, chesscode, map, cc, dd) + big + To_Yammy(to, chesscode, map, cc, dd) + To_Help_Other_Specail(to, chesscode, map, cc, dd) + jumpbonus + To_Help(to, chesscode, map, cc, dd);
        }
    }
    
    LOCATION What_Is_Next(const animal_type & chesscode, int current_x, int current_y, const step_type & direction, const MAP (*map)[7])
    {
        LOCATION to;
        
        switch (direction) {
            case up:
                to.x = current_x + 1;
                to.y = current_y;
                break;
                
            case left:
                to.x = current_x;
                to.y = current_y - 1;
                break;
                
            case down:
                to.x = current_x - 1;
                to.y = current_y;
                break;
                
            case right:
                to.x = current_x;
                to.y = current_y + 1;
                break;
                
            default:
                to.x = current_x;
                to.y = current_y;
                break;
        }
        if (chesscode == tiger || chesscode == lion)
            while(map[to.x][to.y].mtype == water)
            {
                switch (direction) {
                    case up:
                        ++to.x;
                        break;
                        
                    case left:
                        --to.y;
                        break;
                        
                    case down:
                        --to.x;
                        break;
                        
                    case right:
                        ++to.y;
                        break;
                        
                    default:
                        break;
                }
            }
        
        std::cout << "a testing move to (" << to.x << ", " << to.y << ")" << std::endl;
        
        return to;
    }
    
    bool Can_Eat(int prey, int predation, const MAP (*map)[7], const MY_ANIMAL cc[], int xx, int yy)
    {
        if (map[xx][yy].mtype == trap && xx < 6)
            return true;
        if (prey > predation && (prey != 8 || predation != 1))
            return false;
        else if (predation == 1 && map[cc[predation - 1].x][cc[predation - 1].y].mtype != map[xx][yy].mtype)
            return false;
        else if (prey == 1 && predation == 8)
            return false;
        else
            return true;
    }
    
    bool Will_Be_Eat(int prey, int predation, const MAP (*map)[7], const ENEMY dd[], int xx, int yy)
    {
        if (map[xx][yy].mtype == trap && xx > 6)
            return true;
        if (prey > predation && (prey != 8 || predation != 1))
            return false;
        else if (predation == 1 && map[dd[predation - 1].x][dd[predation - 1].y].mtype != map[xx][yy].mtype)
            return false;
        else if (prey == 1 && predation == 8)
            return false;
        else
            return true;
    }
    
    bool Is_Step_Valid(const animal_type & chesscode, const MAP (*map)[7], LOCATION to, const step_type & direction, const MY_ANIMAL cc[])
    {
        if (to.x < 0 || to.x > 8 || to.y < 0 || to.y > 6 || (to.x == 0 && to.y == 3))
            return false;
        
        if (map[to.x][to.y].atype != nanan && cc[int(map[to.x][to.y].atype) - 1].x == to.x && cc[int(map[to.x][to.y].atype) - 1].y == to.y)
            return false;
        
        if (map[to.x][to.y].atype != nanan && !Can_Eat(map[to.x][to.y].atype, chesscode, map, cc, to.x, to.y))
            return false;
        
        if (chesscode != mouse && map[to.x][to.y].mtype == water)
            return false;
        
        if ((chesscode == tiger || chesscode == lion)){
            if (direction == up && map[to.x - 1][to.y].mtype == water){
                for (int i = 3; i < 6; ++i)
                    if (map[i][to.y].atype == mouse) return false;}
            else if (direction == down && map[to.x + 1][to.y].mtype == water){
                for (int i = 3; i < 6; ++i)
                    if (map[i][to.y].atype == mouse) return false;}
            else if (direction == left && map[to.x][to.y + 1].mtype == water){
                for (int i = 1; i < 3; ++i)
                    if (map[to.x][to.y + i].atype == mouse) return false;}
            else if (direction == right && map[to.x][to.y - 1].mtype == water){
                for (int i = 1; i < 3; ++i)
                    if (map[to.x][to.y - i].atype == mouse) return false;}
        }
        return true;
    }
    
    int Vdis(LOCATION to)
    {
        int disans = abs(8 - to.x) + abs(3 - to.y);
        if (disans == 0) return 100000;
        else return 16 - disans;
    }
    
    animal_type Danger_From(const animal_type & chesscode, const MAP (*map)[7], const MY_ANIMAL cc[], const ENEMY dd[])
    {
        if (cc[chesscode - 1].x - 1 >= 0)
        {
            animal_type tea = map[cc[chesscode - 1].x - 1][cc[chesscode - 1].y].atype;
            if (tea != nanan)
            {
                if (dd[tea - 1].x == cc[chesscode - 1].x - 1 && dd[tea - 1].y == cc[chesscode - 1].y && dd[tea - 1].isAlive)
                    if (Will_Be_Eat(chesscode, tea, map, dd, cc[chesscode - 1].x, cc[chesscode - 1].y))
                        return tea;
            }
        }
        if (cc[chesscode - 1].x + 1 <= 8)
        {
            animal_type tea = map[cc[chesscode - 1].x + 1][cc[chesscode - 1].y].atype;
            if (tea != nanan)
            {
                if (dd[tea - 1].x == cc[chesscode - 1].x + 1 && dd[tea - 1].y == cc[chesscode - 1].y && dd[tea - 1].isAlive)
                    if (Will_Be_Eat(chesscode, tea, map, dd, cc[chesscode - 1].x, cc[chesscode - 1].y))
                        return tea;
            }
        }
        if (cc[chesscode - 1].y - 1 >= 0)
        {
            animal_type tea = map[cc[chesscode - 1].x][cc[chesscode - 1].y - 1].atype;
            if (tea != nanan)
            {
                if (dd[tea - 1].x == cc[chesscode - 1].x && dd[tea - 1].y == cc[chesscode - 1].y - 1 && dd[tea - 1].isAlive)
                    if (Will_Be_Eat(chesscode, tea, map, dd, cc[chesscode - 1].x, cc[chesscode - 1].y))
                        return tea;
            }
        }
        if (cc[chesscode - 1].y + 1 <= 6)
        {
            animal_type tea = map[cc[chesscode - 1].x][cc[chesscode - 1].y + 1].atype;
            if (tea != nanan)
            {
                if (dd[tea - 1].x == cc[chesscode - 1].x && dd[tea - 1].y == cc[chesscode - 1].y + 1 && dd[tea - 1].isAlive)
                    if (Will_Be_Eat(chesscode, tea, map, dd, cc[chesscode - 1].x, cc[chesscode - 1].y))
                        return tea;
            }
        }
        return nanan;
    }
    
    int In_Danger_Simple(const animal_type & chesscode, const MAP (*map)[7], const MY_ANIMAL cc[], const ENEMY dd[])
    {
        int more_weight = 0;
        if (chesscode == elephant) more_weight = 3;
        
        if (cc[chesscode - 1].x - 1 >= 0)
        {
            animal_type tea = map[cc[chesscode - 1].x - 1][cc[chesscode - 1].y].atype;
            if (tea != nanan)
            {
                if (dd[tea - 1].x == cc[chesscode - 1].x - 1 && dd[tea - 1].y == cc[chesscode - 1].y && dd[tea - 1].isAlive)
                    if (Will_Be_Eat(chesscode, tea, map, dd, cc[chesscode - 1].x, cc[chesscode - 1].y))
                        return -5 - more_weight;
            }
        }
        if (cc[chesscode - 1].x + 1 <= 8)
        {
            animal_type tea = map[cc[chesscode - 1].x + 1][cc[chesscode - 1].y].atype;
            if (tea != nanan)
            {
                if (dd[tea - 1].x == cc[chesscode - 1].x + 1 && dd[tea - 1].y == cc[chesscode - 1].y && dd[tea - 1].isAlive)
                    if (Will_Be_Eat(chesscode, tea, map, dd, cc[chesscode - 1].x, cc[chesscode - 1].y))
                        return -5 - more_weight;
            }
        }
        if (cc[chesscode - 1].y - 1 >= 0)
        {
            animal_type tea = map[cc[chesscode - 1].x][cc[chesscode - 1].y - 1].atype;
            if (tea != nanan)
            {
                if (dd[tea - 1].x == cc[chesscode - 1].x && dd[tea - 1].y == cc[chesscode - 1].y - 1 && dd[tea - 1].isAlive)
                    if (Will_Be_Eat(chesscode, tea, map, dd, cc[chesscode - 1].x, cc[chesscode - 1].y))
                        return -5 - more_weight;
            }
        }
        if (cc[chesscode - 1].y + 1 <= 6)
        {
            animal_type tea = map[cc[chesscode - 1].x][cc[chesscode - 1].y + 1].atype;
            if (tea != nanan)
            {
                if (dd[tea - 1].x == cc[chesscode - 1].x && dd[tea - 1].y == cc[chesscode - 1].y + 1 && dd[tea - 1].isAlive)
                    if (Will_Be_Eat(chesscode, tea, map, dd, cc[chesscode - 1].x, cc[chesscode - 1].y))
                        return -5 - more_weight;
            }
        }
        return 0;
    }
    
    int In_Danger_Special(const animal_type & chesscode, const MAP (*map)[7], const MY_ANIMAL cc[], const ENEMY dd[])
    {
        if (cc[chesscode - 1].x - 1 >= 0)
        {
            map_type mea = map[cc[chesscode - 1].x - 1][cc[chesscode - 1].y].mtype;
            if (mea == water)
            {
                bool lisafe = false;
                for (int i = 1; i <= 3; ++i)
                    if (map[cc[chesscode - 1].x - i][cc[chesscode - 1].y].atype == mouse) lisafe = true;
                if (!lisafe){
                    animal_type tea = map[cc[chesscode - 1].x - 4][cc[chesscode - 1].y].atype;
                    if ((tea == lion || tea == tiger) && chesscode != elephant)
                        if (dd[tea - 1].x == cc[chesscode - 1].x - 4 && dd[tea - 1].y == cc[chesscode - 1].y)
                            return -5;}
            }

        }
        if (cc[chesscode - 1].x + 1 <= 8)
        {
            map_type mea = map[cc[chesscode - 1].x + 1][cc[chesscode - 1].y].mtype;
            if (mea == water)
            {
                bool lisafe = false;
                for (int i = 1; i <= 3; ++i)
                    if (map[cc[chesscode - 1].x + i][cc[chesscode - 1].y].atype == mouse) lisafe = true;
                if (!lisafe){
                    animal_type tea = map[cc[chesscode - 1].x + 4][cc[chesscode - 1].y].atype;
                    if ((tea == lion || tea == tiger) && chesscode != elephant)
                        if (dd[tea - 1].x == cc[chesscode - 1].x + 4 && dd[tea - 1].y == cc[chesscode - 1].y)
                            return -5;}
            }
            
        }
        if (cc[chesscode - 1].y - 1 >= 0)
        {
            map_type mea = map[cc[chesscode - 1].x][cc[chesscode - 1].y - 1].mtype;
            if (mea == water)
            {
                bool lisafe = false;
                for (int i = 1; i <= 2; ++i)
                    if (map[cc[chesscode - 1].x][cc[chesscode - 1].y - i].atype == mouse) lisafe = true;
                if (!lisafe){
                    animal_type tea = map[cc[chesscode - 1].x][cc[chesscode - 1].y - 3].atype;
                    if ((tea == lion || tea == tiger) && chesscode != elephant)
                        if (dd[tea - 1].x == cc[chesscode - 1].x && dd[tea - 1].y == cc[chesscode - 1].y - 3)
                            return -5;}
            }
            
        }
        if (cc[chesscode - 1].y + 1 >= 0)
        {
            map_type mea = map[cc[chesscode - 1].x][cc[chesscode - 1].y + 1].mtype;
            if (mea == water)
            {
                bool lisafe = false;
                for (int i = 1; i <= 2; ++i)
                    if (map[cc[chesscode - 1].x][cc[chesscode - 1].y + i].atype == mouse) lisafe = true;
                if (!lisafe){
                    animal_type tea = map[cc[chesscode - 1].x][cc[chesscode - 1].y + 3].atype;
                    if ((tea == lion || tea == tiger) && chesscode != elephant)
                        if (dd[tea - 1].x == cc[chesscode - 1].x && dd[tea - 1].y == cc[chesscode - 1].y + 3)
                            return -5;}
            }
            
        }
        return 0;
    }
    
    bool In_Gentle_Help(const animal_type & chesscode, const MAP (*map)[7], const MY_ANIMAL cc[], const ENEMY dd[])
    {
        LOCATION to;
        to.x = cc[chesscode - 1].x;
        to.y = cc[chesscode - 1].y;
        
        if (to.x - 1 >= 0)
        {
            animal_type tea = map[to.x - 1][to.y].atype;
            if (tea != nanan && cc[tea - 1].x == to.x - 1 && cc[tea - 1].y == to.y){
                if (In_Danger_Simple(tea, map, cc, dd) == -5)
                    if (tea != elephant && Can_Eat(Danger_From(tea, map, cc, dd), chesscode, map, cc, to.x - 1, to.y)) // little problem
                        return true;
            }
        }
        if (to.x + 1 <= 8)
        {
            animal_type tea = map[to.x + 1][to.y].atype;
            if (tea != nanan && cc[tea - 1].x == to.x + 1 && cc[tea - 1].y == to.y){
                if (In_Danger_Simple(tea, map, cc, dd) == -5)
                    if (tea != elephant && Can_Eat(Danger_From(tea, map, cc, dd), chesscode, map, cc, to.x + 1, to.y)) // little problem
                        return true;
            }
        }
        if (to.y - 1 >= 0)
        {
            animal_type tea = map[to.x][to.y - 1].atype;
            if (tea != nanan && cc[tea - 1].x == to.x && cc[tea - 1].y == to.y - 1){
                if (In_Danger_Simple(tea, map, cc, dd) == -5)
                    if (tea != elephant && Can_Eat(Danger_From(tea, map, cc, dd), chesscode, map, cc, to.x, to.y - 1)) // little problem
                        return true;
            }
        }
        if (to.y + 1 <= 6)
        {
            animal_type tea = map[to.x][to.y + 1].atype;
            if (tea != nanan && cc[tea - 1].x == to.x && cc[tea - 1].y == to.y + 1){
                if (In_Danger_Simple(tea, map, cc, dd) == -5)
                    if (tea != elephant && Can_Eat(Danger_From(tea, map, cc, dd), chesscode, map, cc, to.x, to.y + 1)) // little problem
                        return true;
            }
        }
        return false;
    }
    
    bool In_Assistant(const animal_type & chesscode, const MAP (*map)[7], const MY_ANIMAL cc[], const ENEMY dd[])
    {
        LOCATION to;
        to.x = cc[chesscode - 1].x;
        to.y = cc[chesscode - 1].y;
        if (chesscode == elephant){
            if (to.x - 1 >= 0)
            {
                animal_type tea = map[to.x - 1][to.y].atype;
                if (tea != nanan && cc[tea - 1].x == to.x - 1 && cc[tea - 1].y == to.y){
                    if (In_Danger_Special(tea, map, cc, dd) == -5)
                        return true;
                }
            }
            if (to.x + 1 <= 8)
            {
                animal_type tea = map[to.x + 1][to.y].atype;
                if (tea != nanan && cc[tea - 1].x == to.x + 1 && cc[tea - 1].y == to.y){
                    if (In_Danger_Special(tea, map, cc, dd) == -5)
                        return true;
                }
            }
            if (to.y - 1 >= 0)
            {
                animal_type tea = map[to.x][to.y - 1].atype;
                if (tea != nanan && cc[tea - 1].x == to.x && cc[tea - 1].y == to.y - 1){
                    if (In_Danger_Special(tea, map, cc, dd) == -5)
                        return true;
                }
            }
            if (to.y + 1 <= 6)
            {
                animal_type tea = map[to.x][to.y + 1].atype;
                if (tea != nanan && cc[tea - 1].x == to.x && cc[tea - 1].y == to.y + 1){
                    if (In_Danger_Special(tea, map, cc, dd) == -5)
                        return true;
                }
            }
        }
        if (to.x - 1 >= 0)
        {
            map_type mea = map[to.x - 1][to.y].mtype;
            if (mea == trap && to.x < 4){
                if (Hole_In_Danger(map, dd, to.x - 1, to.y))
                    return true;
            }
        }
        if (to.x + 1 <= 8)
        {
            map_type mea = map[to.x + 1][to.y].mtype;
            if (mea == trap && to.x < 4){
                if (Hole_In_Danger(map, dd, to.x + 1, to.y))
                    return true;
            }
        }
        if (to.y - 1 >= 0)
        {
            map_type mea = map[to.x][to.y - 1].mtype;
            if (mea == trap && to.x < 4){
                if (Hole_In_Danger(map, dd, to.x, to.y - 1))
                    return true;
            }
        }
        if (to.y + 1 <= 6)
        {
            map_type mea = map[to.x][to.y - 1].mtype;
            if (mea == trap && to.x < 4){
                if (Hole_In_Danger(map, dd, to.x, to.y - 1))
                    return true;
            }
        }
        
        return false;
    }
    
    bool Stop_For_Defense(const animal_type & chesscode, const MAP (*map)[7], const MY_ANIMAL cc[], const ENEMY dd[])
    {
        if (cc[chesscode - 1].x < 4)
        {
            if (cc[chesscode - 1].x - 1 >= 0)
            {
                map_type mea = map[cc[chesscode - 1].x - 1][cc[chesscode - 1].y].mtype;
                if (mea == trap)
                {
                    if (Hole_In_Danger(map, dd, cc[chesscode - 1].x - 1, cc[chesscode - 1].y))
                            return true;
                }
            }
            if (cc[chesscode - 1].x + 1 <= 8)
            {
                map_type mea = map[cc[chesscode - 1].x + 1][cc[chesscode - 1].y].mtype;
                if (mea == trap)
                {
                    if (Hole_In_Danger(map, dd, cc[chesscode - 1].x + 1, cc[chesscode - 1].y))
                        return true;
                }
            }
            if (cc[chesscode - 1].y - 1 >= 0)
            {
                map_type mea = map[cc[chesscode - 1].x][cc[chesscode - 1].y - 1].mtype;
                if (mea == trap)
                {
                    if (Hole_In_Danger(map, dd, cc[chesscode - 1].x, cc[chesscode - 1].y - 1))
                        return true;
                }
            }
            if (cc[chesscode - 1].y + 1 <= 6)
            {
                map_type mea = map[cc[chesscode - 1].x][cc[chesscode - 1].y + 1].mtype;
                if (mea == trap)
                {
                    if (Hole_In_Danger(map, dd, cc[chesscode - 1].x, cc[chesscode - 1].y + 1))
                        return true;
                }
            }
        }
        return false;
    }
    
    int To_Help(const LOCATION to, const animal_type & chesscode, const MAP (*map)[7],const MY_ANIMAL cc[], const ENEMY dd[])
    {
        int help_value = 0;
        if (to.x - 1 >= 0)
        {
            animal_type tea = map[to.x - 1][to.y].atype;
            if (tea != nanan && cc[tea - 1].x == to.x - 1 && cc[tea - 1].y == to.y){
                if (In_Danger_Simple(tea, map, cc, dd) == -5)
                    if (tea != elephant && Can_Eat(Danger_From(tea, map, cc, dd), chesscode, map, cc, to.x - 1, to.y)) // little problem
                    help_value += 5;
            }
        }
        if (to.x + 1 <= 8)
        {
            animal_type tea = map[to.x + 1][to.y].atype;
            if (tea != nanan && cc[tea - 1].x == to.x + 1 && cc[tea - 1].y == to.y){
                if (In_Danger_Simple(tea, map, cc, dd) == -5)
                    if (tea != elephant && Can_Eat(Danger_From(tea, map, cc, dd), chesscode, map, cc, to.x + 1, to.y)) // little problem
                        help_value += 5;
            }
        }
        if (to.y - 1 >= 0)
        {
            animal_type tea = map[to.x][to.y - 1].atype;
            if (tea != nanan && cc[tea - 1].x == to.x && cc[tea - 1].y == to.y - 1){
                if (In_Danger_Simple(tea, map, cc, dd) == -5)
                    if (tea != elephant && Can_Eat(Danger_From(tea, map, cc, dd), chesscode, map, cc, to.x, to.y - 1)) // little problem
                        help_value += 5;
            }
        }
        if (to.y + 1 <= 6)
        {
            animal_type tea = map[to.x][to.y + 1].atype;
            if (tea != nanan && cc[tea - 1].x == to.x && cc[tea - 1].y == to.y + 1){
                if (In_Danger_Simple(tea, map, cc, dd) == -5)
                    if (tea != elephant && Can_Eat(Danger_From(tea, map, cc, dd), chesscode, map, cc, to.x, to.y + 1)) // little problem
                        help_value += 5;
            }
        }
        return help_value;
    }
    
    int To_Help_Other_Specail(const LOCATION to, const animal_type & chesscode, const MAP (*map)[7],const MY_ANIMAL cc[], const ENEMY dd[])
    {
        if (chesscode == elephant){
            if (to.x - 1 >= 0)
            {
                map_type mea = map[to.x - 1][to.y].mtype;
                if (mea == trap && to.x < 4){
                    if (Hole_In_Danger(map, dd, to.x - 1, to.y))
                        return 15;
                }
                animal_type tea = map[to.x - 1][to.y].atype;
                if (tea != nanan && cc[tea - 1].x == to.x - 1 && cc[tea - 1].y == to.y){
                    if (In_Danger_Special(tea, map, cc, dd) == -5)
                        return 10;
                }
            }
            if (to.x + 1 <= 8)
            {
                map_type mea = map[to.x + 1][to.y].mtype;
                if (mea == trap && to.x < 4){
                    if (Hole_In_Danger(map, dd, to.x + 1, to.y))
                        return 15;
                }
                animal_type tea = map[to.x + 1][to.y].atype;
                if (tea != nanan && cc[tea - 1].x == to.x + 1 && cc[tea - 1].y == to.y){
                    if (In_Danger_Special(tea, map, cc, dd) == -5)
                        return 10;
                }
            }
            if (to.y - 1 >= 0)
            {
                map_type mea = map[to.x][to.y - 1].mtype;
                if (mea == trap && to.x < 4){
                    if (Hole_In_Danger(map, dd, to.x, to.y - 1))
                        return 15;
                }
                animal_type tea = map[to.x][to.y - 1].atype;
                if (tea != nanan && cc[tea - 1].x == to.x && cc[tea - 1].y == to.y - 1){
                    if (In_Danger_Special(tea, map, cc, dd) == -5)
                        return 10;
                }
            }
            if (to.y + 1 <= 6)
            {
                map_type mea = map[to.x][to.y - 1].mtype;
                if (mea == trap && to.x < 4){
                    if (Hole_In_Danger(map, dd, to.x, to.y - 1))
                        return 15;
                }
                animal_type tea = map[to.x][to.y + 1].atype;
                if (tea != nanan && cc[tea - 1].x == to.x && cc[tea - 1].y == to.y + 1){
                    if (In_Danger_Special(tea, map, cc, dd) == -5)
                        return 10;
                }
            }
        }
        
        if (to.x - 1 >= 0)
        {
            map_type mea = map[to.x - 1][to.y].mtype;
            if (mea == trap && to.x < 4){
                if (Hole_In_Danger(map, dd, to.x - 1, to.y))
                    return 15;
            }
        }
        if (to.x + 1 <= 8)
        {
            map_type mea = map[to.x + 1][to.y].mtype;
            if (mea == trap && to.x < 4){
                if (Hole_In_Danger(map, dd, to.x + 1, to.y))
                    return 15;
            }
        }
        if (to.y - 1 >= 0)
        {
            map_type mea = map[to.x][to.y - 1].mtype;
            if (mea == trap && to.x < 4){
                if (Hole_In_Danger(map, dd, to.x, to.y - 1))
                    return 15;
            }
        }
        if (to.y + 1 <= 6)
        {
            map_type mea = map[to.x][to.y - 1].mtype;
            if (mea == trap && to.x < 4){
                if (Hole_In_Danger(map, dd, to.x, to.y - 1))
                    return 15;
            }
        }
        
        return 0;
    }

    bool Hole_In_Danger(const MAP (*map)[7], const ENEMY dd[], int xx,int yy)
    {
        if (map[xx][yy - 1].atype != nanan)
        {
            if (dd[map[xx][yy - 1].atype - 1].x == xx && dd[map[xx][yy - 1].atype - 1].y == yy - 1) return true;
        }
        if (map[xx][yy + 1].atype != nanan)
        {
            if (dd[map[xx][yy + 1].atype - 1].x == xx && dd[map[xx][yy + 1].atype - 1].y == yy + 1) return true;
        }
        if (map[xx - 1][yy].atype != nanan)
        {
            if (dd[map[xx - 1][yy].atype - 1].x == xx - 1 && dd[map[xx - 1][yy].atype - 1].y == yy) return true;
        }
        if (map[xx + 1][yy].atype != nanan)
        {
            if (dd[map[xx + 1][yy].atype - 1].x == xx + 1 && dd[map[xx + 1][yy].atype - 1].y == yy) return true;
        }
        return false;
    }
    
    bool To_Danger(const LOCATION to, const animal_type & chesscode, const MAP (*map)[7],const MY_ANIMAL cc[], const ENEMY dd[])
    {
        if (to.x - 1 >= 0)
        {
            animal_type tea = map[to.x - 1][to.y].atype;
            if (tea != nanan)
            {
                if (dd[tea - 1].x == to.x - 1 && dd[tea - 1].y == to.y && dd[tea - 1].isAlive){
                    if (map[to.x][to.y].mtype == trap) return true;
                    if (Will_Be_Eat(chesscode, tea, map, dd, to.x, to.y))
                        return true;}
            }
        }
        if (to.x + 1 <= 8)
        {
            animal_type tea = map[to.x + 1][to.y].atype;
            if (tea != nanan)
            {
                if (dd[tea - 1].x == to.x + 1 && dd[tea - 1].y == to.y && dd[tea - 1].isAlive){
                    if (map[to.x][to.y].mtype == trap) return true;
                    if (Will_Be_Eat(chesscode, tea, map, dd, to.x, to.y))
                        return true;}
            }
        }
        if (to.y - 1 >= 0)
        {
            animal_type tea = map[to.x][to.y - 1].atype;
            if (tea != nanan)
            {
                if (dd[tea - 1].x == to.x && dd[tea - 1].y == to.y - 1 && dd[tea - 1].isAlive){
                    if (map[to.x][to.y].mtype == trap) return true;
                    if (Will_Be_Eat(chesscode, tea, map, dd, to.x, to.y))
                        return true;}
            }
        }
        if (cc[chesscode - 1].y + 1 <= 6)
        {
            animal_type tea = map[to.x][to.y + 1].atype;
            if (tea != nanan)
            {
                if (dd[tea - 1].x == to.x && dd[tea - 1].y == to.y + 1 && dd[tea - 1].isAlive){
                    if (map[to.x][to.y].mtype == trap) return true;
                    if (Will_Be_Eat(chesscode, tea, map, dd, to.x, to.y))
                        return true;}
            }
        }
        return false;
    }
    
    int To_Yammy(const LOCATION to, const animal_type & chesscode, const MAP (*map)[7],const MY_ANIMAL cc[], const ENEMY dd[])
    {
        if (to.x - 1 >= 0)
        {
            animal_type tea = map[to.x - 1][to.y].atype;
            if (tea != nanan)
            {
                if (dd[tea - 1].x == to.x - 1 && dd[tea - 1].y == to.y && dd[tea - 1].isAlive){
                    if (map[to.x][to.y].mtype == trap) return 0;
                    if (Can_Eat(tea, chesscode, map, cc, dd[tea - 1].x, dd[tea - 1].y))
                        return 1;}
            }
        }
        if (to.x + 1 <= 8)
        {
            animal_type tea = map[to.x + 1][to.y].atype;
            if (tea != nanan)
            {
                if (dd[tea - 1].x == to.x + 1 && dd[tea - 1].y == to.y && dd[tea - 1].isAlive){
                    if (map[to.x][to.y].mtype == trap) return 0;
                    if (Can_Eat(tea, chesscode, map, cc, dd[tea - 1].x, dd[tea - 1].y))
                        return 1;}
            }
        }
        if (to.y - 1 >= 0)
        {
            animal_type tea = map[to.x][to.y - 1].atype;
            if (tea != nanan)
            {
                if (dd[tea - 1].x == to.x && dd[tea - 1].y == to.y - 1 && dd[tea - 1].isAlive){
                    if (map[to.x][to.y].mtype == trap) return 0;
                    if (Can_Eat(tea, chesscode, map, cc, dd[tea - 1].x, dd[tea - 1].y))
                        return 1;}
            }
        }
        if (cc[chesscode - 1].y + 1 <= 6)
        {
            animal_type tea = map[to.x][to.y + 1].atype;
            if (tea != nanan)
            {
                if (dd[tea - 1].x == to.x && dd[tea - 1].y == to.y + 1 && dd[tea - 1].isAlive){
                    if (map[to.x][to.y].mtype == trap) return 0;
                    if (Can_Eat(tea, chesscode, map, cc, dd[tea - 1].x, dd[tea - 1].y))
                        return 1;}
            }
        }
        return 0;
    }
    
    bool To_Danger_Specail(const LOCATION to, const animal_type & chesscode, const MAP (*map)[7],const MY_ANIMAL cc[], const ENEMY dd[])
    {
        if (to.x - 1 >= 0)
        {
            map_type mea = map[to.x - 1][to.y].mtype;
            if (mea == water)
            {
                bool lisafe = false;
                for (int i = 1; i <= 3; ++i)
                    if (map[to.x - i][to.y].atype == mouse) lisafe = true;
                if (!lisafe){
                    animal_type tea = map[to.x - 4][to.y].atype;
                    if ((tea == lion || tea == tiger) && chesscode != elephant)
                        if (dd[tea - 1].x == to.x - 4 && dd[tea - 1].y == to.y)
                            return true;}
            }
            
        }
        if (to.x + 1 <= 8)
        {
            map_type mea = map[to.x + 1][to.y].mtype;
            if (mea == water)
            {
                bool lisafe = false;
                for (int i = 1; i <= 3; ++i)
                    if (map[to.x + i][to.y].atype == mouse) lisafe = true;
                if (!lisafe){
                    animal_type tea = map[to.x + 4][to.y].atype;
                    if ((tea == lion || tea == tiger) && chesscode != elephant)
                        if (dd[tea - 1].x == to.x + 4 && dd[tea - 1].y == to.y)
                            return true;}
            }
            
        }
        if (to.y - 1 >= 0)
        {
            map_type mea = map[to.x][to.y - 1].mtype;
            if (mea == water)
            {
                bool lisafe = false;
                for (int i = 1; i <= 2; ++i)
                    if (map[to.x][to.y - i].atype == mouse) lisafe = true;
                if (!lisafe){
                    animal_type tea = map[to.x][to.y - 3].atype;
                    if ((tea == lion || tea == tiger) && chesscode != elephant)
                        if (dd[tea - 1].x == to.x && dd[tea - 1].y == to.y - 3)
                            return true;}
            }
            
        }
        if (to.y + 1 <= 6)
        {
            map_type mea = map[to.x][to.y + 1].mtype;
            if (mea == water)
            {
                bool lisafe = false;
                for (int i = 1; i <= 2; ++i)
                    if (map[to.x][to.y + i].atype == mouse) lisafe = true;
                if (!lisafe){
                    animal_type tea = map[to.x][to.y + 3].atype;
                    if ((tea == lion || tea == tiger) && chesscode != elephant)
                        if (dd[tea - 1].x == to.x && dd[tea - 1].y == to.y + 3)
                            return true;}
            }
            
        }
        return false;
    }
    
    int Yammy(const LOCATION to, const animal_type & chesscode, const MAP (*map)[7],const MY_ANIMAL cc[], const ENEMY dd[])
    {
        animal_type prey = map[to.x][to.y].atype;
        if (prey != nanan)
        {
            int morew = 0;
            if (map[to.x][to.y].mtype == trap && to.x < 4) morew = 100;
            if (Can_Eat(prey, chesscode, map, cc, to.x, to.y))
                return 7 - (int(chesscode) - int(prey)) + morew;
        }
        return 0;
    }
}
